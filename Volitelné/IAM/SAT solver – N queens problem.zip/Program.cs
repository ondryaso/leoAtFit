﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test
{
    class Program
    {
        private static List<string> _clauses;

        // The question is... do we formally prove that this works correctly?
        static void Main(string[] args)
        {
            _clauses = new List<string>();

            var n = 0;
            if (!(args.Length > 0 && int.TryParse(args[0], out n)))
            {
                n = 8;
            }

            Rows(n);
            Constraints(n);

            _clauses = _clauses.Distinct().ToList();

            Console.WriteLine($"p cnf {n * n} {_clauses.Count}");
            foreach (var clause in _clauses)
            {
                Console.WriteLine($"{clause} 0");
            }
        }

        static void Rows(int n)
        {
            var sb = new StringBuilder();
            for (var y = 0; y < n; y++)
            {
                for (var x = 0; x < n; x++)
                {
                    sb.Append($"{y * n + x + 1} ");
                }

                _clauses.Add(sb.ToString().Trim());
                sb.Clear();
            }
        }

        static void Constraints(int n)
        {
            var total = n * n;

            for (var i = 0; i < total; i++)
            {
                // Only one queen in a row
                var rowNum = i / n;
                for (var c = 0; c < n; c++)
                {
                    var pos = rowNum * n + c;
                    if (pos == i) continue;
                    _clauses.Add($"-{i + 1} -{pos + 1}");
                }

                // Only one queen in a column
                var colNum = i % n;
                for (var r = 0; r < n; r++)
                {
                    var pos = r * n + colNum;
                    if (pos == i) continue;
                    _clauses.Add($"-{i + 1} -{pos + 1}");
                }

                // Only one queen in diagonals
                var (x, y) = (colNum + 1, rowNum + 1);
                while (x < n && y < n)
                {
                    var pos = y * n + x;
                    _clauses.Add($"-{i + 1} -{pos + 1}");
                    x++;
                    y++;
                }

                (x, y) = (colNum - 1, rowNum + 1);
                while (x >= 0 && y < n)
                {
                    var pos = y * n + x;
                    _clauses.Add($"-{i + 1} -{pos + 1}");
                    x--;
                    y++;
                }

                (x, y) = (colNum + 1, rowNum - 1);
                while (x < n && y >= 0)
                {
                    var pos = y * n + x;
                    _clauses.Add($"-{i + 1} -{pos + 1}");
                    x++;
                    y--;
                }

                (x, y) = (colNum - 1, rowNum - 1);
                while (x >= 0 && y >= 0)
                {
                    var pos = y * n + x;
                    _clauses.Add($"-{i + 1} -{pos + 1}");
                    x--;
                    y--;
                }
            }
        }
    }
}