# IDS, part 4, web scraping ORM script
# Authors: xnecas27 and xondry02
# Oracle client is required to connect to DB with Oracle_cx
# Python >= 3.6 required

import datetime
import random
import re
import requests
import time
from sqlalchemy.engine import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy import Column, Integer, String, NVARCHAR, ForeignKey, TIMESTAMP, Numeric, Date,\
    text, extract, or_, and_, desc
from bs4 import BeautifulSoup

Base = declarative_base()
Session = sessionmaker()

# The connection string construction is inspired by user's Dataku (https://stackoverflow.com/users/5540273/dataku)
# answer on Stack Exchange Network: https://stackoverflow.com/a/57693172 in response to the following question
# https://stackoverflow.com/q/28453545
DIALECT = 'oracle'
SQL_DRIVER = 'cx_oracle'
# TODO: Add your user/password here
USERNAME = ''
PASSWORD = ''
HOST = 'gort.fit.vutbr.cz'
PORT = 1521
SERVICE = 'orclpdb'
ENGINE_PATH_WIN_AUTH = DIALECT + '+' + SQL_DRIVER + '://' + USERNAME + ':' + PASSWORD + '@' +\
                       HOST + ':' + str(PORT) + '/?service_name=' + SERVICE

BASE_URL = 'https://www.restu.cz'
SCRAPING_URL = BASE_URL + '/brno/kavarna/'


class Cafe(Base):
    __tablename__ = 'cafe'

    id = Column(Integer, primary_key=True)
    name = Column(NVARCHAR(128))
    address_line = Column(NVARCHAR(128))
    city = Column(NVARCHAR(128))
    website = Column(NVARCHAR(128), nullable=True)
    capacity = Column(Integer, nullable=True)
    description = Column(String, nullable=True)
    average_rating = Column(Numeric(scale=2), default=0)


class OpeningHours(Base):
    __tablename__ = 'openinghours'

    cafe_id = Column(Integer, ForeignKey(Cafe.id), primary_key=True)
    day_of_week = Column(Integer, primary_key=True)
    time_from = Column(TIMESTAMP, primary_key=True)
    time_to = Column(TIMESTAMP)


class SUserLimited(Base):
    __tablename__ = 'suserlimited'

    id = Column(Integer, primary_key=True)
    favourite_drink = Column(NVARCHAR(128), nullable=True)
    favourite_coffee = Column(NVARCHAR(128), nullable=True)
    cups_per_day = Column(Integer, nullable=True)
    email = Column(NVARCHAR(320))
    favourite_cafe_id = Column(Integer, ForeignKey(Cafe.id), nullable=True)


class CafeRating(Base):
    __tablename__ = 'caferating'

    user_id = Column(Integer, ForeignKey(SUserLimited.id), primary_key=True)
    cafe_id = Column(Integer, ForeignKey(Cafe.id), primary_key=True)
    rating = Column(Numeric(2, 1))
    date_modified = Column(Date, default=datetime.datetime.now)


class CafeReview(Base):
    __tablename__ = 'cafereview'

    id = Column(Integer, primary_key=True)
    content = Column(NVARCHAR(2000))
    date_added = Column(Date, default=datetime.datetime.now)
    date_of_visit = Column(Date, nullable=True)
    points_up = Column(Integer, default=0)
    points_down = Column(Integer, default=0)
    made_by_user_id = Column(Integer, ForeignKey(SUserLimited.id))
    reacts_to_id = Column(Integer, ForeignKey('cafereview.id'), nullable=True)
    reviews_cafe_id = Column(Integer, ForeignKey(Cafe.id))


def get_pages():
    # The site consists of pages, get the number of them
    site = requests.get(SCRAPING_URL)
    soup = BeautifulSoup(site.content, 'html.parser')
    pages = []
    # Go through the pagination menu and find the maximum page
    for tag in soup.find_all('a', class_='pagination-link'):
        if 'href' in tag.attrs:
            match = re.search(r'page=(\d+)', str(tag.attrs['href']))
            if match:
                pages.append(int(match.group(1)))
    return max(pages)


DAYS_MAPPING = {
    'pondělí': 0,
    'úterý': 1,
    'středa': 2,
    'čtvrtek': 3,
    'pátek': 4,
    'sobota': 5,
    'neděle': 6,
}


def get_datetime(hours_minutes):
    hours_minutes = hours_minutes.strip()
    # The site uses 24:00 which is not a valid time
    if hours_minutes == '24:00':
        hours_minutes = '23:59'
    today = datetime.datetime.today()
    return datetime.datetime.combine(today, datetime.datetime.strptime(hours_minutes, '%H:%M').time())


def scrape_opening_hours(db_session, cafe, soup):
    found = set()
    for day in soup.find_all('ul', class_='c-opening-list-item'):
        day_num = DAYS_MAPPING[day.find('li', 'opening-list__day').text.lower()]
        if day_num in found:
            # The days are sometimes repeated for unknown reasons...
            continue
        opening = day.find('span', class_='opening-list__time').text
        if opening == 'Zavřeno':
            continue
        split = opening.split('-')
        start = get_datetime(split[0])
        end = get_datetime(split[1])
        if start > end:
            # Handle cases such as 17:00 - 1:00, split into two time blocks
            new_start = get_datetime('00:00')
            new_end = end
            new_day = (day_num + 1) % 7
            print(new_day, new_start, new_end)
            db_session.add(OpeningHours(cafe_id=cafe.id, day_of_week=new_day, time_from=new_start, time_to=new_end))
            end = get_datetime('23:59')

        found.add(day_num)
        print(day_num, start, end)
        db_session.add(OpeningHours(cafe_id=cafe.id, day_of_week=day_num, time_from=start, time_to=end))


def scrape_reviews(db_session, cafe, soup):
    available_reviews = 3
    users = list(db_session.query(SUserLimited).order_by(text('dbms_random.value')).limit(available_reviews))
    i = 0
    for review in soup.find_all('article', class_='c-review-item-card'):
        if i >= len(users):
            return
        user = users[i]
        i += 1

        # Get the rating and convert to a max 5 (their max is 15)
        total = 0
        for point in review.find_all('div', class_='points'):
            total += int(point.text)
        rating = (total / 15) * 5
        print(f'Rating: {rating}')
        db_session.add(CafeRating(user_id=user.id, cafe_id=cafe.id, rating=rating))

        # Create a review
        content = str(review.find('p', class_='summary').text)
        if not content:
            continue
        print(f'Review: {content}')
        db_session.add(CafeReview(content=content, made_by_user_id=user.id, reviews_cafe_id=cafe.id))


def scrape_one_cafe(db_session, name, relative_url):
    if not name or not relative_url:
        return
    print(f'Scraping data for {name} on {relative_url}')
    url = BASE_URL + relative_url
    site = requests.get(url)
    soup = BeautifulSoup(site.content, 'html.parser')

    # Cafe data
    address = str(soup.find('address', class_='restaurant-detail-address').next.next)
    city = 'Brno'
    website = url
    capacity = random.randrange(20, 60)
    description = soup.find('div', class_='restaurant-desc').text
    print(name, address, city, website, capacity, description)
    new_cafe = Cafe(name=name, address_line=address, city=city, website=website, capacity=capacity,
                    description=description)
    db_session.add(new_cafe)
    db_session.flush()

    scrape_opening_hours(db_session, new_cafe, soup)
    scrape_reviews(db_session, new_cafe, soup)
    db_session.commit()
    print()


def scrape_data(db_session):
    pages = get_pages()
    for page in range(1, pages + 1):
        url = SCRAPING_URL + f'?page={page}'
        site = requests.get(url)
        soup = BeautifulSoup(site.content, 'html.parser')
        # Go through the restaurants
        for tag in soup.find_all('a', class_='card-item-link'):
            scrape_one_cafe(db_session, tag.attrs.get('data-name', None), tag.attrs.get('href', None))
        # Sleep for some time so that we don't flood their server...
        print('One page processed... sleeping')
        time.sleep(5)


# Demonstrate some of the selects using ORM
def demonstrate_queries(db_session):
    # Find a Cafe with an average rating of at least 4 which is open right now
    now = datetime.datetime.now()
    today = now.weekday()
    for row in db_session.query(Cafe, OpeningHours)\
            .join(OpeningHours)\
            .filter(Cafe.average_rating >= 4)\
            .filter(OpeningHours.day_of_week == today)\
            .filter(or_(
                extract('hour', OpeningHours.time_from) < now.hour,
                and_(
                    extract('hour', OpeningHours.time_from) == now.hour,
                    extract('minute', OpeningHours.time_from) <= now.minute
                )))\
            .filter(or_(
                extract('hour', OpeningHours.time_to) > now.hour,
                and_(
                    extract('hour', OpeningHours.time_to) == now.hour,
                    extract('minute', OpeningHours.time_to) >= now.minute)))\
            .order_by(desc(Cafe.average_rating)):
        print(row[0].name, row[0].address_line, row[0].average_rating, row[1].time_from, row[1].time_to)


if __name__ == '__main__':
    engine = create_engine(ENGINE_PATH_WIN_AUTH)
    Session.configure(bind=engine)
    session = Session()
    # TODO: change/remove this based on the schema used
    session.execute('ALTER SESSION SET CURRENT_SCHEMA = xondry02')
    scrape_data(session)
    demonstrate_queries(session)
    session.close()
